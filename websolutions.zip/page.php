<?php
$discounts_json = file_get_contents('assets/js/pages/json/discounts.json');

$discounts = json_decode($discounts_json, true);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="ThemeMakker">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>:: BigBucket :: Blank Page</title>

    <link rel="stylesheet" href="../assets/vendor/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="../assets/vendor/fontawesome/css/font-awesome.min.css">

    <link rel="stylesheet" href="../assets/css/main.css" type="text/css">
</head>

<body class="theme-indigo" style="background-color:#fff !important;">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30"><img src="../assets/images/brand/icon_black.svg" width="48" height="48" alt="ArrOw"></div>
            <p>Please wait...</p>
        </div>
    </div>

    <nav class="navbar custom-navbar navbar-expand-lg py-2">
        <div class="container-fluid px-0">
            <a href="javascript:void(0);" class="menu_toggle"><i class="fa fa-align-left"></i></a>
            <a href="index.html" class="navbar-brand"><img src="../assets/images/logo.png" alt="CompanyLogo" />
                <strong>Company</strong>Logo</a>
            <div id="navbar_main">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link nav-link-icon" href="#">Home</a></li>
                    <li class="nav-item"><a class="nav-link nav-link-icon" href="#">About us</a></li>
                    <li class="nav-item"><a class="nav-link nav-link-icon" href="#">Software</a></li>
                    <li class="nav-item"><a class="nav-link nav-link-icon" href="#">Pricing</a></li>
                    <li class="nav-item"><button type="button" class="btn btn-block btn-primary">Get Started</button></li>
                </ul>
            </div>
        </div>
    </nav>
	
	<div class="container-fluid px-0" style="margin-top: 110px;background-color: #000;">
		<div style="background: rgb(0 0 0 / 30%) url(assets/images/header-bg.png);padding: 110px 15px 110px;margin-top:110px;background-blend-mode: color;">
			<div class="container-fluid py-2 pt-2" style="margin-left: auto;margin-right: auto;max-width: 940px;text-align: center;background-blend-mode: difference;">
				<span style="margin-bottom: 30px;color: #fff;font-family: Roboto, sans-serif;font-size: 60px;line-height: 1.2em;display: block;">
					What is Lorem Ipsum?
				</span>
				<span style="margin-bottom: 30px;font-family: Roboto, sans-serif;color: #fff;font-size: 22px;line-height:1.2em;display: block;">
					Lorem Ipsum is simply dummy text of the printing and typesetting industry.
				</span>
				<div style="display: inline-block; line-height:1.2em">
					<button type="button" class="btn btn-block btn-primary" style="padding: 0.4rem 2.5rem;font-size: 20px;">Button</button>
				</div>
			</div>
		</div>
	</div>

    <div class="main_content" id="main-content" style="padding:47px 30px 40px;background-color:#f7f7f7">
        <div class="page">
            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-4 col-sm-12" style="padding: 0 10px;line-height:1.8em">
						<img src="assets/images/check.png" style="display:block; float:left; margin-right: 12px;">
						<div style="display:block;font-size:18px;text-align:left">
							Contrary to popular belief, Lorem Ipsum is not simply random text
						</div>
					</div>
                    <div class="col-lg-4 col-md-4 col-sm-12" style="padding: 0 10px;line-height:1.8em">
						<img src="assets/images/check.png" style="display:block; float:left; margin-right: 12px;">
						<div style="display:block;font-size:18px;text-align:left">
							Lorem ipsum dolor sit amet, consectetur adipiscing elit
						</div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12" style="padding: 0 10px;line-height:1.8em">
						<img src="assets/images/check.png" style="display:block; float:left; margin-right: 12px;">
						<div style="display:block;font-size:18px;text-align:left">
							The standard chunk of Lorem Ipsum used since 1500s  is reproduced
						</div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	<div class="main_content" id="main-content">
        <div class="page">
			<div class="container-fluid" style="padding:47px 30px 40px;">
				<H1 class="heading heading-1 mb-4">Where does it come from?</H1>
				<span>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</span>
			</div>
			<div class="container-fluid" style="padding:47px 30px 40px;">
				<H1 class="heading heading-1 mb-4">Where can I get some?</H1>
				<span>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</span>
			</div>
		</div>
	</div>
	<div class="main_content" id="main-content" style="padding:47px 30px 40px;background-color:#f7f7f7">
        <div class="page" style="width:100%">
			<div class="container-fluid">
				<H1 class="heading heading-1 mb-4" style="color: #000">Discounts</H1>
				
<?php

foreach ($discounts as $key) {
?>
				<div class="row clearfix" style="margin-bottom: 60px;">
					<div class="col-lg-12 col-md-12" style="padding: 0 90px">
<?php
					if ($key['sticky'] != NULL) {
?>
						<div style="background: url('assets/images/discount-banner-bg.png') no-repeat left top; height: 36px; margin-bottom: -22px; width:100%; display:block; padding-left: 10px; color: #fff; line-height: 1.8em; font-size: 16px; margin-left: -8px;position: sticky; text-align:left"><?php echo $key['sticky']; ?></div>
<?php
					}
?>
						<div style="background-color: #fff;text-align: left;margin-top: 0px;border: #ddd 1px solid;border-radius: 10px;padding: 36px 36px 18px;box-shadow: 0px 6px 12px -6px black;">
							<div class="row clearfix">
								<div class="col-lg-10 col-md-10 col-sm-10" style="margin-right: -4px;">
									<div class="row clearfix">
										<div class="col-3" style="margin-right: -4px;">
											<h3 style="line-height:1em;"><?php echo $key['name']; ?></h3>
										</div>
										<span style="color:#888">|</span>
										<div class="col-9" style="line-height: 2em;padding-left: 40px;">
											<h6 style="line-height:2em; color: #3968a0;"><?php echo $key['retention']; ?> - <?php echo $key['servers']; ?></h6>
										</div>
										<div class="col-3">
											<i class="fa fa-tag" style="font-size: 16px;"></i>  <?php echo $key['price']; ?>
										</div>
										<div class="col-3">
											<i class="fa fa-download" style="font-size: 16px;"></i>  <?php echo $key['downloads']; ?>
										</div>
										<div class="col-3">
											<i class="fa fa-tachometer" style="font-size: 16px;"></i>  <?php echo $key['speed']; ?>
										</div>
									</div>
								</div>
								<div class="col-lg-2 col-md-2 col-sm-2">
<?php
								if ($key['button']==1) {
?>
									<button type="button" class="btn btn-block btn-primary" style="padding: 8px 10px;border-radius: 15px;">Button</button>
<?php
								} else {
?>
									<button type="button" class="btn btn-block btn-primary grey" style="padding: 8px 10px;border-radius: 15px;">Button</button>
<?php
								}
?>
								</div>
							</div>
							<div class="row clearfix">
								<div class="col-12" style="padding-top: 10px">
									<i class="fa <?php echo $key['desc_icon']; ?>" style="font-size: 20px;color:#43c124;line-height:1em"></i> <span style="font-size:16px;line-height:2em"> <?php echo $key['desc']; ?></span>
								</div>
							</div>
						</div>
					</div>
				</div>
<?php
}
?>
			</div>
        </div>    
    </div>
	<div class="main_content" id="main-content">
        <div class="page">
			<div class="container-fluid" style="padding:47px 30px 40px;">
				<H1 class="heading heading-1 mb-4">FAQ's</H1>
				<div class="faq-acc" style="font-size:18px">
					<div style="display: inline-block; width: calc(100% - 20px);text-align:left; padding: 0 60px;font-weight: bold;">
						Why do we use it?
					</div>
					<div style="width:20px; float: right;">
						<i class="fa fa-chevron-circle-down"></i>
					</div>
				</div>
				<div class="faq-panel" style="padding: 0 60px;">
					<p style="text-align:left;">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
				</div>
				<div class="faq-acc" style="font-size:18px;">
					<div style="display: inline-block; width: calc(100% - 20px);text-align:left; padding: 0 60px;font-weight: bold;">
						Where can I get some?
					</div>
					<div style="width:20px; float: right;">
						<i class="fa fa-chevron-circle-down"></i>
					</div>
				</div>
				<div class="faq-panel" style="padding: 0 60px;">
					<p style="text-align:left;">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing </p>
				</div>
				<div class="faq-acc" style="font-size:18px;">
					<div style="display: inline-block; width: calc(100% - 20px);text-align:left; padding: 0 60px;font-weight: bold;">
						Where does it come from?
					</div>
					<div style="width:20px; float: right;">
						<i class="fa fa-chevron-circle-down"></i>
					</div>
				</div>
				<div class="faq-panel" style="padding: 0 60px;">
					<p style="text-align:left;">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections</p>
				</div>
				
			</div>
		</div>
	</div>
	<nav class="navbar" style="background-color:#000;height:120px;">
        <div class="container-fluid px-0">
            2021 All rights reserved
            <div style="float: left">
                <ul style="display:flex; flex-direction:row; list-style:none; margin-left: auto !important; padding-left:0; margin-bottom:0">
                    <li style="display: inline-flex;"><a style="color:#495057" href="#">Privacy Policy</a></li>
                    <li style="display: inline-flex;"><a style="color:#495057" href="#">Terms of Service</a></li>
                    <li style="display: inline-flex;"><a style="color:#495057" href="#">Copyright Policy</a></li>
                </ul>
            </div>
        </div>
    </nav>
<!-- Javascript -->
<script src="assets/bundles/libscripts.bundle.js"></script>    
<script src="assets/bundles/vendorscripts.bundle.js"></script>

<script src="assets/js/theme.js"></script>
<script>
var acc = document.getElementsByClassName("faq-acc");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
	  $("div.faq-acc div i").removeClass("fa-chevron-circle-down");
	  $("div.faq-acc div i").addClass("fa-chevron-circle-up");
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
	  $("div.faq-acc div i").addClass("fa-chevron-circle-down");
	  $("div.faq-acc div i").removeClass("fa-chevron-circle-up");
    } 
  });
}
</script>
</body>
</html>